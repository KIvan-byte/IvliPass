// SavedFragment.java
package com.example.myapplication.ui.saved;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.R;

/**
 * Фрагмент для отображения сохраненных паролей.
 */
public class SavedFragment extends Fragment {

    private SavedViewModel savedViewModel;
    private EditText serviceNameEditText;
    private TextView passwordTextView;
    private Button retrievePasswordButton;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_saved, container, false);

        // Инициализация элементов интерфейса
        serviceNameEditText = root.findViewById(R.id.serviceNameEditText);
        passwordTextView = root.findViewById(R.id.passwordTextView);
        retrievePasswordButton = root.findViewById(R.id.retrievePasswordButton);

        // Инициализация ViewModel
        savedViewModel = new ViewModelProvider(this).get(SavedViewModel.class);

        // Установка обработчика для кнопки извлечения пароля
        retrievePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String service = serviceNameEditText.getText().toString().trim();

                if (TextUtils.isEmpty(service)) {
                    Toast.makeText(getContext(), "Введите название сервиса", Toast.LENGTH_SHORT).show();
                    return;
                }

                String password = savedViewModel.getPassword(service);

                if (password != null) {
                    passwordTextView.setText("Password: " + password);
                } else {
                    passwordTextView.setText("Пароль не найден для указанного сервиса.");
                }
            }
        });

        return root;
    }
}
