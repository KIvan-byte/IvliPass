// PasswordRepository.java
package com.example.myapplication.repository;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import com.example.myapplication.utils.KeyStoreManager;
import com.example.myapplication.utils.SecurePreferences;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;

/**
 * Репозиторий для управления сохраненными паролями.
 */
public class PasswordRepository {

    private static PasswordRepository instance;
    private SecurePreferences securePreferences;
    private KeyStoreManager keyStoreManager;

    private PasswordRepository(Context context) {
        securePreferences = new SecurePreferences(context);
        keyStoreManager = new KeyStoreManager();
        keyStoreManager.generateKey();
    }

    /**
     * Возвращает единственный экземпляр PasswordRepository.
     *
     * @param context контекст приложения.
     * @return экземпляр PasswordRepository.
     */
    public static synchronized PasswordRepository getInstance(Context context) {
        if (instance == null) {
            instance = new PasswordRepository(context);
        }
        return instance;
    }

    /**
     * Извлекает пароль для указанного сервиса.
     *
     * @param service название сервиса.
     * @return расшифрованный пароль или null, если не найден.
     */
    public String getPassword(String service) {
        try {
            String encryptedPasswordBase64 = securePreferences.getString("password_" + service, null);
            String encryptionIvBase64 = securePreferences.getString("iv_" + service, null);

            if (encryptedPasswordBase64 == null || encryptionIvBase64 == null) {
                return null;
            }

            byte[] encryptedPassword = Base64.decode(encryptedPasswordBase64, Base64.DEFAULT);
            byte[] encryptionIv = Base64.decode(encryptionIvBase64, Base64.DEFAULT);

            Cipher cipher = keyStoreManager.getCipherForDecryption(encryptionIv);
            byte[] decryptedPassword = cipher.doFinal(encryptedPassword);
            return new String(decryptedPassword, StandardCharsets.UTF_8);

        } catch (Exception e) {
            e.printStackTrace();
            Log.e("PasswordRepository", "Ошибка дешифрования пароля", e);
            return null;
        }
    }

    // Добавьте другие методы по необходимости (например, savePassword)
}
