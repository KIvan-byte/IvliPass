// KeyStoreManager.java
package com.example.myapplication.utils;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.charset.StandardCharsets;

public class KeyStoreManager {

    private static final String KEYSTORE_ALIAS = "MyAppKey";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";

    private KeyStore keyStore;

    public KeyStoreManager() {
        try {
            keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
            keyStore.load(null);
        } catch (GeneralSecurityException | IOException e) {
            e.printStackTrace();
            Log.e("KeyStoreManager", "Ошибка загрузки KeyStore", e);
        }
    }

    /**
     * Генерация криптографического ключа, если он еще не существует.
     */
    public void generateKey() {
        try {
            if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
                KeyGenParameterSpec keyGenParameterSpec = new KeyGenParameterSpec.Builder(
                        KEYSTORE_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
                )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build();

                KeyGenerator keyGenerator = KeyGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_AES,
                        ANDROID_KEYSTORE
                );
                keyGenerator.init(keyGenParameterSpec);
                keyGenerator.generateKey();
                Log.d("KeyStoreManager", "Ключ сгенерирован");
            } else {
                Log.d("KeyStoreManager", "Ключ уже существует");
            }
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
            Log.e("KeyStoreManager", "Ошибка генерации ключа", e);
        }
    }

    /**
     * Возвращает инициализированный Cipher для шифрования.
     *
     * @return Cipher для шифрования данных.
     */
    public Cipher getCipherForEncryption() {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey());
            return cipher;
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
            Log.e("KeyStoreManager", "Ошибка инициализации Cipher", e);
            return null;
        }
    }

    /**
     * Возвращает секретный ключ из Keystore.
     *
     * @return SecretKey для шифрования/дешифрования.
     * @throws GeneralSecurityException если ключ не найден или возникает ошибка.
     */
    public SecretKey getSecretKey() throws GeneralSecurityException {
        return (SecretKey) keyStore.getKey(KEYSTORE_ALIAS, null);
    }

    /**
     * Возвращает инициализированный Cipher для дешифрования.
     *
     * @param iv Initialization Vector, использованный при шифровании.
     * @return Cipher для дешифрования данных.
     * @throws GeneralSecurityException если возникает ошибка.
     */
    public Cipher getCipherForDecryption(byte[] iv) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        GCMParameterSpec spec = new GCMParameterSpec(128, iv);
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec);
        return cipher;
    }

    /**
     * Дешифрует зашифрованные данные с использованием IV.
     *
     * @param encryptedData зашифрованные данные.
     * @param iv            Initialization Vector.
     * @return Расшифрованные данные как строка.
     * @throws GeneralSecurityException если дешифрование не удалось.
     */
    public String decrypt(byte[] encryptedData, byte[] iv) throws GeneralSecurityException {
        Cipher cipher = getCipherForDecryption(iv);
        byte[] decryptedBytes = cipher.doFinal(encryptedData);
        return new String(decryptedBytes, StandardCharsets.UTF_8); // Преобразование байтов в строку без необходимости обработки исключений

    }
}
