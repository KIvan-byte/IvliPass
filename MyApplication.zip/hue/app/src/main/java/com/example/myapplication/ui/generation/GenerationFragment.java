// GenerationFragment.java
package com.example.myapplication.ui.generation;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.R;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Фрагмент для генерации и сохранения паролей.
 */
public class GenerationFragment extends Fragment {

    private TextView generatedPasswordTextView;
    private SeekBar passwordLengthSeekBar;
    private TextView passwordLengthText;
    private CheckBox specialSymbolsCheckbox;
    private GenerationViewModel generationViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_generation, container, false);

        generatedPasswordTextView = view.findViewById(R.id.textView);
        passwordLengthSeekBar = view.findViewById(R.id.passwordLengthSeekBar);
        passwordLengthText = view.findViewById(R.id.passwordLengthText);
        specialSymbolsCheckbox = view.findViewById(R.id.specialSymbolsCheckbox);
        Button generatePasswordButton = view.findViewById(R.id.generatePasswordButton);
        Button savePasswordButton = view.findViewById(R.id.savePasswordButton);

        // Инициализируем ViewModel
        generationViewModel = new ViewModelProvider(this).get(GenerationViewModel.class);

        // Устанавливаем минимальное значение SeekBar
        passwordLengthSeekBar.setMax(20);
        passwordLengthSeekBar.setProgress(8);
        passwordLengthText.setText("Password Length: 8");

        // Обновляем текст длины пароля при изменении SeekBar
        passwordLengthSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int length = Math.max(8, progress); // Минимальная длина 8
                passwordLengthText.setText("Password Length: " + length);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        // Генерация пароля
        generatePasswordButton.setOnClickListener(v -> generatePassword());

        // Сохранение пароля
        savePasswordButton.setOnClickListener(v -> savePassword());

        return view;
    }

    /**
     * Генерирует случайный пароль и отображает его.
     */
    private void generatePassword() {
        int length = Math.max(8, passwordLengthSeekBar.getProgress());
        boolean includeSpecialSymbols = specialSymbolsCheckbox.isChecked();
        String generatedPassword = generateRandomPassword(length, includeSpecialSymbols);
        generatedPasswordTextView.setText(generatedPassword);
    }

    /**
     * Генерирует случайный пароль с учетом заданных параметров.
     *
     * @param length               длина пароля.
     * @param includeSpecialSymbols включать ли специальные символы.
     * @return сгенерированный пароль.
     */
    private String generateRandomPassword(int length, boolean includeSpecialSymbols) {
        String lower = "abcdefghijklmnopqrstuvwxyz";
        String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String digits = "0123456789";
        String special = "!@#$%^&*()_+-=[]{}|;':\",.<>?";

        StringBuilder charSet = new StringBuilder(lower + upper + digits);
        if (includeSpecialSymbols) {
            charSet.append(special);
        }

        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder(length);

        // Обеспечьте наличие хотя бы одного символа из каждой категории
        password.append(lower.charAt(random.nextInt(lower.length())));
        password.append(upper.charAt(random.nextInt(upper.length())));
        password.append(digits.charAt(random.nextInt(digits.length())));
        if (includeSpecialSymbols) {
            password.append(special.charAt(random.nextInt(special.length())));
        }

        for (int i = password.length(); i < length; i++) {
            int index = random.nextInt(charSet.length());
            password.append(charSet.charAt(index));
        }

        // Перемешайте символы
        List<Character> passwordChars = new ArrayList<>();
        for (char c : password.toString().toCharArray()) {
            passwordChars.add(c);
        }
        Collections.shuffle(passwordChars, random);

        StringBuilder finalPassword = new StringBuilder();
        for (char c : passwordChars) {
            finalPassword.append(c);
        }

        return finalPassword.toString();
    }

    /**
     * Сохраняет сгенерированный пароль.
     */
    private void savePassword() {
        String service = ((TextView) getView().findViewById(R.id.serviceEditText)).getText().toString().trim();
        String email = ((TextView) getView().findViewById(R.id.emailEditText)).getText().toString().trim();
        String password = generatedPasswordTextView.getText().toString();

        if (TextUtils.isEmpty(service) || TextUtils.isEmpty(password)) {
            Toast.makeText(getContext(), "Service and Password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        generationViewModel.savePassword(service, email, password);
        Toast.makeText(getContext(), "Password saved successfully", Toast.LENGTH_SHORT).show();
    }
}
