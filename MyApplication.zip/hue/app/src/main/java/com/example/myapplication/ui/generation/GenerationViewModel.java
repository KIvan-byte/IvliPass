// GenerationViewModel.java
package com.example.myapplication.ui.generation;

import android.app.Application;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.example.myapplication.utils.KeyStoreManager;
import com.example.myapplication.utils.SecurePreferences;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;

import javax.crypto.Cipher;

/**
 * ViewModel для GenerationFragment, отвечающий за генерацию и сохранение паролей.
 */
public class GenerationViewModel extends AndroidViewModel {

    private static final String TAG = "GenerationViewModel";
    private SecurePreferences securePreferences;
    private KeyStoreManager keyStoreManager;

    public GenerationViewModel(@NonNull Application application) {
        super(application);
        securePreferences = new SecurePreferences(application);
        keyStoreManager = new KeyStoreManager();
        keyStoreManager.generateKey();
    }

    /**
     * Сохраняет зашифрованный пароль вместе с IV.
     *
     * @param service  название сервиса.
     * @param email    email пользователя (опционально).
     * @param password сгенерированный пароль.
     */
    public void savePassword(String service, String email, String password) {
        try {
            Cipher cipher = keyStoreManager.getCipherForEncryption();
            if (cipher == null) {
                Log.e(TAG, "Инициализация Cipher не удалась");
                return;
            }

            byte[] encryptionIv = cipher.getIV();
            byte[] encryptedPassword = cipher.doFinal(password.getBytes(StandardCharsets.UTF_8));

            // Кодируем в Base64 для хранения в SharedPreferences
            String encryptedPasswordBase64 = Base64.encodeToString(encryptedPassword, Base64.DEFAULT);
            String encryptionIvBase64 = Base64.encodeToString(encryptionIv, Base64.DEFAULT);

            // Сохраняем зашифрованный пароль и IV
            securePreferences.putString("password_" + service, encryptedPasswordBase64);
            securePreferences.putString("iv_" + service, encryptionIvBase64);

            // Сохраняем email, если необходимо
            securePreferences.putString("email_" + service, email);

            Log.d(TAG, "Пароль успешно сохранен");
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
            Log.e(TAG, "Ошибка шифрования пароля", e);
        }
    }

    /**
     * Извлекает и дешифрует пароль для указанного сервиса.
     *
     * @param service название сервиса.
     * @return расшифрованный пароль или null, если не найден.
     */
    public String getPassword(String service) {
        try {
            String encryptedPasswordBase64 = securePreferences.getString("password_" + service, null);
            String encryptionIvBase64 = securePreferences.getString("iv_" + service, null);

            if (encryptedPasswordBase64 == null || encryptionIvBase64 == null) {
                return null;
            }

            byte[] encryptedPassword = Base64.decode(encryptedPasswordBase64, Base64.DEFAULT);
            byte[] encryptionIv = Base64.decode(encryptionIvBase64, Base64.DEFAULT);

            Cipher cipher = keyStoreManager.getCipherForDecryption(encryptionIv);
            byte[] decryptedPassword = cipher.doFinal(encryptedPassword);
            return new String(decryptedPassword, StandardCharsets.UTF_8);

        } catch (GeneralSecurityException e) {
            e.printStackTrace();
            Log.e(TAG, "Ошибка дешифрования пароля", e);
            return null;
        }
    }
}
