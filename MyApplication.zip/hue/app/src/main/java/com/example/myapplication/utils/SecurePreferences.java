// SecurePreferences.java
package com.example.myapplication.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

/**
 * Утилитный класс для безопасного хранения данных с использованием EncryptedSharedPreferences.
 */
public class SecurePreferences {

    private static final String PREFS_FILENAME = "secure_prefs";
    private SharedPreferences sharedPreferences;

    /**
     * Конструктор инициализирует EncryptedSharedPreferences.
     *
     * @param context Контекст приложения.
     */
    public SecurePreferences(Context context) {
        try {
            // Создание MasterKey для шифрования
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            // Инициализация EncryptedSharedPreferences
            sharedPreferences = EncryptedSharedPreferences.create(
                    context,
                    PREFS_FILENAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException | IOException e) {
            e.printStackTrace();
            Log.e("SecurePreferences", "Ошибка инициализации EncryptedSharedPreferences", e);
        }
    }

    /**
     * Сохраняет строковое значение в зашифрованных SharedPreferences.
     *
     * @param key   Ключ для сохранения значения.
     * @param value Значение для сохранения.
     */
    public void putString(String key, String value) {
        if (sharedPreferences != null) {
            sharedPreferences.edit().putString(key, value).apply();
        } else {
            Log.e("SecurePreferences", "SharedPreferences не инициализированы");
        }
    }

    /**
     * Извлекает строковое значение из зашифрованных SharedPreferences.
     *
     * @param key          Ключ для извлечения значения.
     * @param defaultValue Значение по умолчанию, если ключ не найден.
     * @return Извлеченное значение или defaultValue.
     */
    public String getString(String key, String defaultValue) {
        if (sharedPreferences != null) {
            return sharedPreferences.getString(key, defaultValue);
        } else {
            Log.e("SecurePreferences", "SharedPreferences не инициализированы");
            return defaultValue;
        }
    }

    /**
     * Сохраняет целочисленное значение в зашифрованных SharedPreferences.
     *
     * @param key   Ключ для сохранения значения.
     * @param value Значение для сохранения.
     */
    public void putInt(String key, int value) {
        if (sharedPreferences != null) {
            sharedPreferences.edit().putInt(key, value).apply();
        } else {
            Log.e("SecurePreferences", "SharedPreferences не инициализированы");
        }
    }

    /**
     * Извлекает целочисленное значение из зашифрованных SharedPreferences.
     *
     * @param key          Ключ для извлечения значения.
     * @param defaultValue Значение по умолчанию, если ключ не найден.
     * @return Извлеченное значение или defaultValue.
     */
    public int getInt(String key, int defaultValue) {
        if (sharedPreferences != null) {
            return sharedPreferences.getInt(key, defaultValue);
        } else {
            Log.e("SecurePreferences", "SharedPreferences не инициализированы");
            return defaultValue;
        }
    }

    // Добавьте другие методы (putBoolean, getBoolean и т.д.) по мере необходимости
}
