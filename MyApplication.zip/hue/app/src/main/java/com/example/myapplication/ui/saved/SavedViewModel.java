// SavedViewModel.java
package com.example.myapplication.ui.saved;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

import com.example.myapplication.repository.PasswordRepository;

/**
 * ViewModel для SavedFragment, отвечающий за извлечение сохраненных паролей.
 */
public class SavedViewModel extends AndroidViewModel {

    private PasswordRepository passwordRepository;

    public SavedViewModel(@NonNull Application application) {
        super(application);
        passwordRepository = PasswordRepository.getInstance(application.getApplicationContext());
    }

    /**
     * Извлекает пароль для указанного сервиса.
     *
     * @param service название сервиса.
     * @return расшифрованный пароль или null, если не найден.
     */
    public String getPassword(String service) {
        return passwordRepository.getPassword(service);
    }
}
